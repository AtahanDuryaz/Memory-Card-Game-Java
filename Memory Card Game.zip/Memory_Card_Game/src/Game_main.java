
public class Game_main {

	public static void main(String[] args) {
		new Menu();
		
	}

}
